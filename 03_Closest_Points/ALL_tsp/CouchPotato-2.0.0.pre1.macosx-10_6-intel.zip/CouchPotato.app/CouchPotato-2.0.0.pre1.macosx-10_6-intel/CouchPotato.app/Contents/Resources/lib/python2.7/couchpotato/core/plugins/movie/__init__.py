from .main import MoviePlugin

def start():
    return MoviePlugin()

config = []
