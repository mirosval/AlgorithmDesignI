from .main import WHiWA

def start():
    return WHiWA()

config = []
