from .main import IMDBAPI

def start():
    return IMDBAPI()

config = []
