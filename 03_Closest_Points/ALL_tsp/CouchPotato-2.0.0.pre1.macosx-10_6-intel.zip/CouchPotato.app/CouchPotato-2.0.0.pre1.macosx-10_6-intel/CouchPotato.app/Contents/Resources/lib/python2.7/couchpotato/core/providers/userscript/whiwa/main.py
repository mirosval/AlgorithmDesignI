from couchpotato.core.providers.userscript.base import UserscriptBase


class WHiWA(UserscriptBase):

    includes = ['http://whiwa.net/stats/movie/*']
