from .main import FileBrowser

def start():
    return FileBrowser()

config = []
