from .main import MovieResultModifier

def start():

    return MovieResultModifier()

config = []
