from .main import TMDB

def start():
    return TMDB()

config = []
