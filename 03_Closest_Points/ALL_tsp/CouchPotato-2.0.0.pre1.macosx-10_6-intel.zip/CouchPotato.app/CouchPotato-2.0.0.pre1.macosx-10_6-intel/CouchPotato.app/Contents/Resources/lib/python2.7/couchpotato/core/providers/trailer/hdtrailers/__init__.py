from .main import HDTrailers

def start():
    return HDTrailers()

config = []
